// Sample Data for Display
const patients = [
    { id: 1, firstName: 'John', lastName: 'Doe', gender: 'Male', bloodGroup: 'O+' },
    { id: 2, firstName: 'Jane', lastName: 'Smith', gender: 'Female', bloodGroup: 'A-' }
  ];
  
  const rooms = [
    { id: 1, name: 'Room 101', available: 'Yes' },
    { id: 2, name: 'Room 102', available: 'No' }
  ];
  
  const staff = [
    { id: 1, firstName: 'Adam', lastName: 'Adam', type: 'Doctor', email: 'adam@example.com' },
    { id: 2, firstName: 'Sarah', lastName: 'Connor', type: 'Nurse', email: 'sarah@example.com' }
  ];
  
  // Populate Tables
  document.getElementById('patientData').innerHTML = patients.map(patient => `
    <tr>
      <td>${patient.id}</td>
      <td>${patient.firstName}</td>
      <td>${patient.lastName}</td>
      <td>${patient.gender}</td>
      <td>${patient.bloodGroup}</td>
    </tr>
  `).join('');
  
  document.getElementById('roomData').innerHTML = rooms.map(room => `
    <tr>
      <td>${room.id}</td>
      <td>${room.name}</td>
      <td>${room.available}</td>
    </tr>
  `).join('');
  
  document.getElementById('staffData').innerHTML = staff.map(member => `
    <tr>
      <td>${member.id}</td>
      <td>${member.firstName}</td>
      <td>${member.lastName}</td>
      <td>${member.type}</td>
      <td>${member.email}</td>
    </tr>
  `).join('');
  
  // Tab Control
  function openTable(evt, tableName) {
    const tabcontent = document.getElementsByClassName("tabcontent");
    for (let i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    const tablinks = document.getElementsByClassName("tablinks");
    for (let i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tableName).style.display = "block";
    evt.currentTarget.className += " active";
  }
  